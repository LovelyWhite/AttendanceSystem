create procedure updateTotalTimeByCid(IN `_cid` int(20))
  BEGIN
	UPDATE syllabus SET totaltime= (totaltime+1)	WHERE cid = _cid;
END;

