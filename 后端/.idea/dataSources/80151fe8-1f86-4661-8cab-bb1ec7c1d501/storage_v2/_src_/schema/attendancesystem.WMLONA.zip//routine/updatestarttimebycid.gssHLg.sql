create procedure updateStartTimeByCid(IN cid int(20))
  BEGIN
	UPDATE courses SET startTime = now()	WHERE courseid = cid;
END;

