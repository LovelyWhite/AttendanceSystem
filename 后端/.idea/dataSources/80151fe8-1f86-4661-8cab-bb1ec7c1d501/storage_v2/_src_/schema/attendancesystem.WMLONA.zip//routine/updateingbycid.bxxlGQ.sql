create procedure updateIngByCid(IN cid int(20))
  BEGIN
	DECLARE _ing INT;
	SELECT ing INTO _ing FROM courses
	WHERE courseid = cid;
	IF _ing = 1 THEN
		UPDATE courses SET ing = 0 	WHERE courseid = cid;
	ELSE
		UPDATE courses SET ing = 1 	WHERE courseid = cid;
	END IF;
END;

